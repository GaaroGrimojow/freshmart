const express = require("express");
const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const dataDir = path.join(__dirname, "..", "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "freshmart.sqlite"));
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL CHECK(price >= 0),
    unit TEXT NOT NULL,
    image TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    stock INTEGER NOT NULL DEFAULT 100 CHECK(stock >= 0)
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_number TEXT NOT NULL UNIQUE,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT NOT NULL,
    payment_method TEXT NOT NULL,
    total REAL NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL REFERENCES orders(id),
    product_id INTEGER NOT NULL REFERENCES products(id),
    product_name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    unit_price REAL NOT NULL
  );
`);

const productCount = db.prepare("SELECT COUNT(*) AS count FROM products").get().count;
if (productCount === 0) {
  const products = [
    ["Red Apples", "Fruits", 149, "1 kg", "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?auto=format&fit=crop&w=700&q=80", "Crisp and juicy apples."],
    ["Bananas", "Fruits", 55, "1 dozen", "https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?auto=format&fit=crop&w=700&q=80", "Naturally sweet bananas."],
    ["Fresh Oranges", "Fruits", 89, "1 kg", "https://images.unsplash.com/photo-1547514701-42782101795e?auto=format&fit=crop&w=700&q=80", "Bright, citrusy oranges."],
    ["Tomatoes", "Vegetables", 36, "1 kg", "https://images.unsplash.com/photo-1546094096-0df4bcaaa337?auto=format&fit=crop&w=700&q=80", "Fresh everyday tomatoes."],
    ["Carrots", "Vegetables", 48, "1 kg", "https://images.unsplash.com/photo-1445282768818-728615cc910a?auto=format&fit=crop&w=700&q=80", "Crunchy farm-fresh carrots."],
    ["Spinach", "Vegetables", 25, "1 bunch", "https://images.unsplash.com/photo-1576045057995-568f588f82fb?auto=format&fit=crop&w=700&q=80", "Leafy greens for your meals."],
    ["Farm Milk", "Dairy", 32, "500 ml", "https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=700&q=80", "Fresh milk for every day."],
    ["Cheddar Cheese", "Dairy", 120, "200 g", "https://images.unsplash.com/photo-1486297678162-eb2a19b0a32d?auto=format&fit=crop&w=700&q=80", "Rich and creamy cheese."],
    ["Whole Wheat Bread", "Bakery", 45, "1 loaf", "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=700&q=80", "Soft bread baked fresh."],
    ["Oat Cookies", "Snacks", 75, "1 pack", "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&w=700&q=80", "A sweet tea-time snack."],
    ["Orange Juice", "Beverages", 95, "1 litre", "https://images.unsplash.com/photo-1600271886742-f049cd451bba?auto=format&fit=crop&w=700&q=80", "Refreshing orange juice."],
    ["Basmati Rice", "Pantry", 135, "1 kg", "https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=700&q=80", "Fragrant rice for family meals."]
  ];
  const insert = db.prepare("INSERT INTO products (name, category, price, unit, image, description) VALUES (?, ?, ?, ?, ?, ?)");
  const transaction = db.transaction((rows) => rows.forEach(row => insert.run(...row)));
  transaction(products);
}

app.use(express.json({ limit: "100kb" }));
app.use(express.static(path.join(__dirname, "..", "public")));

app.get("/api/health", (_req, res) => res.json({ status: "ok", service: "FreshMart API" }));
app.get("/api/categories", (_req, res) => {
  const categories = db.prepare("SELECT DISTINCT category FROM products ORDER BY category").all().map(row => row.category);
  res.json(categories);
});
app.get("/api/products", (req, res) => {
  const search = String(req.query.search || "").trim().slice(0, 80);
  const category = String(req.query.category || "").trim().slice(0, 50);
  let sql = "SELECT id, name, category, price, unit, image, description, stock FROM products WHERE stock > 0";
  const params = [];
  if (search) {
    sql += " AND (name LIKE ? OR description LIKE ? OR category LIKE ?)";
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (category && category !== "All") {
    sql += " AND category = ?";
    params.push(category);
  }
  sql += " ORDER BY category, name";
  res.json(db.prepare(sql).all(...params));
});

app.post("/api/orders", (req, res) => {
  const { customerName, phone, address, paymentMethod, items } = req.body || {};
  if (typeof customerName !== "string" || customerName.trim().length < 2 || customerName.trim().length > 80) {
    return res.status(400).json({ error: "Please enter a valid name." });
  }
  if (typeof phone !== "string" || !/^[0-9+\-\s()]{7,20}$/.test(phone.trim())) {
    return res.status(400).json({ error: "Please enter a valid phone number." });
  }
  if (typeof address !== "string" || address.trim().length < 8 || address.trim().length > 500) {
    return res.status(400).json({ error: "Please enter a delivery address (at least 8 characters)." });
  }
  if (!["Cash on Delivery", "Pay on Delivery (UPI)"].includes(paymentMethod)) {
    return res.status(400).json({ error: "Please choose a supported demo payment method." });
  }
  if (!Array.isArray(items) || items.length < 1 || items.length > 50) {
    return res.status(400).json({ error: "Your cart is empty or contains too many different products." });
  }

  try {
    const normalized = [];
    const getProduct = db.prepare("SELECT id, name, price, stock FROM products WHERE id = ?");
    for (const item of items) {
      const id = Number(item.productId);
      const quantity = Number(item.quantity);
      if (!Number.isInteger(id) || !Number.isInteger(quantity) || quantity < 1 || quantity > 99) {
        return res.status(400).json({ error: "One or more cart items are invalid." });
      }
      const product = getProduct.get(id);
      if (!product || product.stock < quantity) {
        return res.status(400).json({ error: "A product is unavailable or has insufficient stock. Please refresh your cart." });
      }
      normalized.push({ ...product, quantity });
    }
    const total = Math.round(normalized.reduce((sum, p) => sum + p.price * p.quantity, 0) * 100) / 100;
    const orderNumber = "FM-" + Date.now().toString(36).toUpperCase() + "-" + Math.random().toString(36).slice(2, 6).toUpperCase();

    const createOrder = db.transaction(() => {
      const result = db.prepare(`
        INSERT INTO orders (order_number, customer_name, phone, address, payment_method, total)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(orderNumber, customerName.trim(), phone.trim(), address.trim(), paymentMethod, total);
      const orderId = result.lastInsertRowid;
      const insertItem = db.prepare(`
        INSERT INTO order_items (order_id, product_id, product_name, quantity, unit_price)
        VALUES (?, ?, ?, ?, ?)
      `);
      normalized.forEach(p => insertItem.run(orderId, p.id, p.name, p.quantity, p.price));
      return orderId;
    });
    createOrder();
    res.status(201).json({ message: "Order placed successfully.", orderNumber, total });
  } catch (err) {
    console.error("Order creation failed:", err.message);
    res.status(500).json({ error: "Unable to place your order right now. Please try again." });
  }
});

app.get("/api/orders/:orderNumber", (req, res) => {
  const orderNumber = String(req.params.orderNumber || "").slice(0, 40);
  const order = db.prepare(`
    SELECT order_number AS orderNumber, customer_name AS customerName, payment_method AS paymentMethod,
           total, created_at AS createdAt
    FROM orders WHERE order_number = ?
  `).get(orderNumber);
  if (!order) return res.status(404).json({ error: "Order not found." });
  const items = db.prepare(`
    SELECT product_name AS name, quantity, unit_price AS unitPrice
    FROM order_items WHERE order_id = (SELECT id FROM orders WHERE order_number = ?)
  `).all(orderNumber);
  res.json({ ...order, items });
});

app.listen(PORT, () => {
  console.log(`FreshMart is running at http://localhost:${PORT}`);
  console.log("API health check: http://localhost:" + PORT + "/api/health");
});
