# FreshMart Grocery

A starter full-stack grocery shop using HTML, CSS, JavaScript, Node.js, Express, and SQLite.

## Requirements
- Node.js LTS and npm

## Run locally
1. Open this folder in Google Antigravity.
2. Open its terminal in the project folder.
3. Run `npm install`
4. Run `npm start`
5. Open `http://localhost:3000`

The SQLite database and sample products are created automatically in `data/freshmart.sqlite`.

## Included
- Product search and category filters
- Add/remove cart items and quantity controls
- Cart saved in browser localStorage
- Checkout form
- Server-side price calculation and order validation
- SQLite order persistence
- Order confirmation number

## Notes
This is a demo checkout. It does not process real payments. The selected payment method is recorded as an order preference only.
