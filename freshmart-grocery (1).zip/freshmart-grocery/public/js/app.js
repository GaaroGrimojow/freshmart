const state = {
  products: [],
  categories: [],
  category: "All",
  search: "",
  cart: JSON.parse(localStorage.getItem("freshmart-cart") || "[]")
};

const $ = (selector) => document.querySelector(selector);
const productGrid = $("#productGrid");
const statusMessage = $("#statusMessage");
const cartDrawer = $("#cartDrawer");
const overlay = $("#overlay");
const checkoutModal = $("#checkoutModal");
const money = (value) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 2 }).format(value);

$("#year").textContent = new Date().getFullYear();

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data;
}

async function loadStore() {
  try {
    const [products, categories] = await Promise.all([api("/api/products"), api("/api/categories")]);
    state.products = products;
    state.categories = categories;
    renderCategories();
    renderProducts();
    statusMessage.textContent = `${products.length} fresh picks to explore`;
  } catch (error) {
    statusMessage.textContent = "We couldn't load the products. Please check that the backend is running and refresh.";
    showToast(error.message);
  }
}

function renderCategories() {
  const holder = $("#categoryFilters");
  holder.innerHTML = "";
  ["All", ...state.categories].forEach(category => {
    const button = document.createElement("button");
    button.className = `filter-chip${state.category === category ? " active" : ""}`;
    button.dataset.category = category;
    button.textContent = category === "All" ? "All groceries" : category;
    button.addEventListener("click", () => {
      state.category = category;
      renderCategories();
      renderProducts();
    });
    holder.appendChild(button);
  });
}

function renderProducts() {
  const search = state.search.toLowerCase();
  const products = state.products.filter(product => {
    const matchesCategory = state.category === "All" || product.category === state.category;
    const matchesSearch = `${product.name} ${product.category} ${product.description}`.toLowerCase().includes(search);
    return matchesCategory && matchesSearch;
  });
  productGrid.innerHTML = "";
  if (!products.length) {
    productGrid.innerHTML = '<div class="empty-state">No groceries found. Try another search or category.</div>';
    return;
  }
  products.forEach(product => {
    const card = document.createElement("article");
    card.className = "product-card";
    card.innerHTML = `
      <div class="product-image-wrap">
        <img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" loading="lazy">
        <span class="fresh-tag">FRESH PICK</span>
      </div>
      <div class="product-info">
        <div class="product-category">${escapeHtml(product.category)} · ${escapeHtml(product.unit)}</div>
        <h3>${escapeHtml(product.name)}</h3>
        <p class="product-description">${escapeHtml(product.description)}</p>
        <div class="product-bottom">
          <div class="product-price">${money(product.price)} <small>/ ${escapeHtml(product.unit)}</small></div>
          <button class="add-button" aria-label="Add ${escapeHtml(product.name)} to cart" data-add="${product.id}">+</button>
        </div>
      </div>`;
    card.querySelector("[data-add]").addEventListener("click", () => addToCart(product.id));
    const image = card.querySelector("img");
    image.addEventListener("error", () => { image.src = "https://placehold.co/600x450/f1f5e9/285c36?text=FreshMart"; }, { once: true });
    productGrid.appendChild(card);
  });
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[char]));
}

function saveCart() {
  localStorage.setItem("freshmart-cart", JSON.stringify(state.cart));
  renderCart();
}

function addToCart(productId) {
  const product = state.products.find(item => item.id === productId);
  if (!product) return;
  const existing = state.cart.find(item => item.productId === productId);
  if (existing) {
    if (existing.quantity >= 99) return showToast("Maximum quantity is 99 per item.");
    existing.quantity += 1;
  } else {
    state.cart.push({ productId, quantity: 1 });
  }
  saveCart();
  showToast(`${product.name} added to your cart`);
}

function changeQuantity(productId, delta) {
  const item = state.cart.find(row => row.productId === productId);
  if (!item) return;
  item.quantity += delta;
  if (item.quantity <= 0) state.cart = state.cart.filter(row => row.productId !== productId);
  if (item.quantity > 99) item.quantity = 99;
  saveCart();
}

function cartProducts() {
  return state.cart.map(item => {
    const product = state.products.find(row => row.id === item.productId);
    return product ? { ...product, quantity: item.quantity } : null;
  }).filter(Boolean);
}

function renderCart() {
  const products = cartProducts();
  const count = products.reduce((sum, product) => sum + product.quantity, 0);
  const total = products.reduce((sum, product) => sum + product.price * product.quantity, 0);
  $("#cartCount").textContent = count;
  $("#drawerCount").textContent = `(${count})`;
  $("#cartSubtotal").textContent = money(total);
  $("#checkoutTotal").textContent = money(total);
  const holder = $("#cartItems");
  holder.innerHTML = "";
  if (!products.length) {
    holder.innerHTML = '<div class="cart-empty"><span>🧺</span><strong>Your basket is taking a little nap.</strong><p>Add something fresh to get started.</p></div>';
    return;
  }
  products.forEach(product => {
    const line = document.createElement("div");
    line.className = "cart-line";
    line.innerHTML = `
      <img src="${escapeHtml(product.image)}" alt="">
      <div>
        <h3>${escapeHtml(product.name)}</h3>
        <small>${money(product.price)} / ${escapeHtml(product.unit)}</small>
        <div class="quantity-control">
          <button data-delta="-1" aria-label="Decrease quantity">−</button>
          <span>${product.quantity}</span>
          <button data-delta="1" aria-label="Increase quantity">+</button>
        </div>
        <button class="remove-line" data-remove>Remove</button>
      </div>
      <div class="cart-line-total">${money(product.price * product.quantity)}</div>`;
    line.querySelectorAll("[data-delta]").forEach(button => button.addEventListener("click", () => changeQuantity(product.id, Number(button.dataset.delta))));
    line.querySelector("[data-remove]").addEventListener("click", () => {
      state.cart = state.cart.filter(item => item.productId !== product.id);
      saveCart();
    });
    holder.appendChild(line);
  });
}

function openCart() {
  cartDrawer.classList.add("open");
  cartDrawer.setAttribute("aria-hidden", "false");
  overlay.classList.add("visible");
}
function closeCart() {
  cartDrawer.classList.remove("open");
  cartDrawer.setAttribute("aria-hidden", "true");
  overlay.classList.remove("visible");
}
function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("visible");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("visible"), 2600);
}

$("#searchInput").addEventListener("input", event => {
  state.search = event.target.value.trim();
  renderProducts();
});
$("#openCart").addEventListener("click", openCart);
$("#closeCart").addEventListener("click", closeCart);
overlay.addEventListener("click", closeCart);
$("#checkoutButton").addEventListener("click", () => {
  if (!state.cart.length) return showToast("Your cart is empty — add a few fresh picks first.");
  closeCart();
  $("#checkoutForm").hidden = false;
  $("#orderSuccess").hidden = true;
  checkoutModal.classList.add("visible");
  checkoutModal.setAttribute("aria-hidden", "false");
});
$("#closeCheckout").addEventListener("click", () => {
  checkoutModal.classList.remove("visible");
  checkoutModal.setAttribute("aria-hidden", "true");
});
checkoutModal.addEventListener("click", event => {
  if (event.target === checkoutModal) {
    checkoutModal.classList.remove("visible");
    checkoutModal.setAttribute("aria-hidden", "true");
  }
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") {
    closeCart();
    checkoutModal.classList.remove("visible");
    checkoutModal.setAttribute("aria-hidden", "true");
  }
});
document.addEventListener("keydown", event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    $("#searchInput").focus();
  }
});

$("#checkoutForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.currentTarget;
  if (!form.reportValidity()) return;
  if (!state.cart.length) return showToast("Your cart is empty.");
  const submit = form.querySelector("button[type=submit]");
  submit.disabled = true;
  submit.innerHTML = "Placing order…";
  const formData = new FormData(form);
  const payload = {
    customerName: formData.get("customerName"),
    phone: formData.get("phone"),
    address: formData.get("address"),
    paymentMethod: formData.get("paymentMethod"),
    items: state.cart.map(item => ({ productId: item.productId, quantity: item.quantity }))
  };
  try {
    const result = await api("/api/orders", { method: "POST", body: JSON.stringify(payload) });
    state.cart = [];
    saveCart();
    form.hidden = true;
    const success = $("#orderSuccess");
    success.hidden = false;
    success.innerHTML = `<h3>🎉 Order placed!</h3><p>Thanks, ${escapeHtml(payload.customerName)}. Your demo order number is <strong>${escapeHtml(result.orderNumber)}</strong>.</p><p>Order total: <strong>${money(result.total)}</strong></p><p>This is a demo order. No payment has been taken.</p>`;
  } catch (error) {
    showToast(error.message);
  } finally {
    submit.disabled = false;
    submit.innerHTML = 'Place demo order <span>→</span>';
  }
});

renderCart();
loadStore();
